import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
  isRegister = false;
  user = {};
  
  toggleRegister(isRegistered){
    this.isRegister = isRegistered;
    console.log(this.isRegister);
    alert(isRegistered);
  }

  loginUser(user){
    if(user.username == "qwe" && user.password =="qwe"){
      console.log("Logged in!!");
    } else {
      console.log("Failed!!")
    }
  }

}
