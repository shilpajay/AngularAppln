import { Component } from '@angular/core';

@Component({
  selector: 'selector',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'My First Project';
  newData = ['One','Two','Three','Four'];
  bindings="abcdefg";

  heros = [
    {id: 1, name:'Superman'},
    {id: 2, name:'Batman'},
    {id: 5, name:'BatGirl'},
    {id: 3, name:'Robin'},
    {id: 4, name:'Flash'}
];
  alertFunction(heros){
    alert(JSON.stringify(heros));
    alert('Hello! You clicked the button!');
  }
}
